// música 1
var music1 = document.getElementById("musica-1");
var icon1 = document.getElementById("icon-1");

icon1.onclick = function(){
    if(music1.paused){
        music1.play();
        icon1.src = "assets/imagens/pause.png";
    } else {
        music1.pause();
        icon1.src = "assets/imagens/play.png";
    }
}

// música 2

var music2 = document.getElementById("musica-2");
var icon2 = document.getElementById("icon-2");

icon2.onclick = function(){
    if(music2.paused){
        music2.play();
        icon2.src = "assets/imagens/pause.png";
    }else{
        music2.pause();
        icon2.src = "assets/imagens/play.png";
    }
}

// música 3

var music3 = document.getElementById("musica-3");
var icon3 = document.getElementById("icon-3");

icon3.onclick = function(){
    if(music3.paused){
        music3.play();
        icon3.src = "assets/imagens/pause.png";
    }else{
        music3.pause();
        icon3.src = "assets/imagens/play.png";
    }
}

// música 4

var music4 = document.getElementById("musica-4");
var icon4 = document.getElementById("icon-4");

icon4.onclick = function(){
    if(music4.paused){
        music4.play();
        icon4.src = "assets/imagens/pause.png";
    }else{
        music4.pause();
        icon4.src = "assets/imagens/play.png";
    }
}

// música 5

var music5 = document.getElementById("musica-5");
var icon5 = document.getElementById("icon-5");

icon5.onclick = function(){
    if(music5.paused){
        music5.play();
        icon5.src = "assets/imagens/pause.png";
    }else{
        music5.pause();
        icon5.src = "assets/imagens/play.png";
    }
}

// música 6

var music6 = document.getElementById("musica-6");
var icon6 = document.getElementById("icon-6");

icon6.onclick = function(){
    if(music6.paused){
        music6.play();
        icon6.src = "assets/imagens/pause.png";
    }else{
        music6.pause();
        icon6.src = "assets/imagens/play.png";
    }
}

// música 7

var music7 = document.getElementById("musica-7");
var icon7 = document.getElementById("icon-7");

icon7.onclick = function(){
    if(music7.paused){
        music7.play();
        icon7.src = "assets/imagens/pause.png";
    }else{
        music7.pause();
        icon7.src = "assets/imagens/play.png";
    }
}